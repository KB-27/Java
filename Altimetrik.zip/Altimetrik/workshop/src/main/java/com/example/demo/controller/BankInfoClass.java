package com.example.demo.controller;


import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.BankInfoSercice;

//controller
@RestController

public class BankInfoClass {
	@Autowired
	BankInfoSercice s;

	@RequestMapping(value="/bankinfo/{code}" , method=RequestMethod.GET)
	public String getCode(@PathVariable("code") String code){
		System.out.println("Code####"+code);
		String a=s.getBankInfoFromCode(code);
	
		return a;
	}

}
