package com.example.demo.service;

import java.util.List;

import org.json.JSONObject;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

//Service
@Service
public class BankInfoSercice {
	
	public String getBankInfoFromCode(String code){
		
		final String uri = "http://api.worldbank.org/v2/country/"+code+"?format=json";
		System.out.println("uri####"+uri);
		RestTemplate restTemplate = new RestTemplate();
		try{
		String result = restTemplate.getForObject(uri, String.class);
		
		
		//String ss=result.substring(376,420);
		//System.out.println("substring####"+ss);
		//System.out.println("result####"+result);
		return result;
			}catch (Exception e){
				e.printStackTrace();
				return "Exception"+e;
			}
		}

}
